This is a aircraft update. PLEASE BACK UP YOUR ORIGINAL FILE. 

This is a fix for the Autopilot occsilation issues in MS2020 747-8I

Plane is able to be flown safely and without occsilations it is good to note that the plane might experience minor occisilations with weather changes.

Plane can fly up to 4X without occsilations.

Plane is more stable and YAW has been fixed to be more accurate.

Plane VNAV no longer shoots you up and down thruoughout the flight and holds stable at all operating altitudes. MTOW limits aircraft altitude ceiling.

This is not a long term project but may end up into a more long term project after we expereince the ASOBO update coming soon!

Credits:DemonicPepsi69!, Rdy?

Feel free to contact us with any questions in the MSFS2020 discord. 

